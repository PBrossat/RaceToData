# -*- coding: utf-8 -*-
"""
:summary: 
:author: francis.horsman@gmail.com
"""

if __name__ == '__main__':  # pragma no cover
    pass
