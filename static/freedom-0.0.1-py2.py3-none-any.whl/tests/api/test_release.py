# -*- coding: utf-8 -*-

import unittest


class Test_release(unittest.TestCase):
    def setUp(self):
        pass

    def tearDown(self):
        pass


if __name__ == '__main__':  # pragma no cover
    unittest.main()
